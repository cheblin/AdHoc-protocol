package org.unirail.BlackBox;

//полное либо выборочное отключение использования базового протокола
public class SimpleProtocol {}
