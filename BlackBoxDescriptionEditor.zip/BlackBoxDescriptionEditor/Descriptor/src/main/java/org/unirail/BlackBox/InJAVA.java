package org.unirail.BlackBox;

public interface InJAVA {}
