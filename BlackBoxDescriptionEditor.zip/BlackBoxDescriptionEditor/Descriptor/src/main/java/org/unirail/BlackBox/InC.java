package org.unirail.BlackBox;

public interface InC {}
