package org.unirail.BlackBox;

public interface InCS {}
