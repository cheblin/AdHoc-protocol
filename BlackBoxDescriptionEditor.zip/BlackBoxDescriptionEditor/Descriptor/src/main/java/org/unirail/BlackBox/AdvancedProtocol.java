package org.unirail.BlackBox;

//включение расширенного протокола на устройстве
public class AdvancedProtocol {}
