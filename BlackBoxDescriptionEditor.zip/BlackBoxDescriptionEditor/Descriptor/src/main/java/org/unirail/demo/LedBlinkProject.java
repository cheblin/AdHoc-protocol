package org.unirail.demo;

import org.unirail.BlackBox.*;

class LedBlinkProject {}

/**
 * User interface control device <-> Microcontroller : communication channel
 */
class LedBoard_User_Channel extends AdvancedProtocol implements LedBoard.Main, UserInterface.Main {}

/**
 * Any type Microcontroller board with LED
 */
class LedBoard implements InC {
	interface Main  {
		class SwitchModeCommand {// switch blink mode user command pack
		}
	}
}

/**
 * User side control device
 */
class UserInterface implements InJAVA, InCS {
	interface Main {
		class HeartBeat {// Pack send by Microcontroller board
			int       beat; // Microcontroller beat counter value report
			LED_state led_state; //Microcontroller current led LED_state report
		}
	}
}

 enum LED_state {
	 on, off
}

